#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include <string.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"

#define MEM_SIZE 4
static void syscall_handler (struct intr_frame *);

static void
syscall_handler (struct intr_frame *f UNUSED) 
{

    uint32_t sys_num=*((uint32_t*)(f->esp));
    uint32_t arg1 =*(uint32_t*)(f->esp+MEM_SIZE);
    uint32_t arg2 =*(uint32_t*)(f->esp+2*MEM_SIZE);
    uint32_t arg3 =*(uint32_t*)(f->esp+3*MEM_SIZE);
    uint32_t arg4 =*(uint32_t*)(f->esp+4*MEM_SIZE);
    user_vaddr(f->esp+4);
	switch(sys_num){
		case SYS_HALT:
			syscall_halt();
			break;
		case SYS_EXIT:
			syscall_exit(arg1);
			break;
		case SYS_EXEC :
			f->eax = syscall_exec((char*)arg1);
			break;
        case SYS_WAIT:
			f->eax = syscall_wait(arg1);
			break;
		case SYS_READ:
			f->eax = syscall_read ((int)arg1,(void*)arg2,(unsigned)arg3);
			break;
		case SYS_WRITE:
			f->eax = syscall_write((int)arg1,(const void*)arg2,(unsigned)arg3);
			break;
		case SYS_FIB:
			f->eax=syscall_fibonacci((int)arg1);
			break;
		case SYS_MAXFOUR:
			f->eax=syscall_max_of_four_int((int)arg1, (int)arg2,(int)arg3, (int)arg4);
			break;
   } 

	return;
}
void
syscall_init (void)
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void user_vaddr(const void *vaddr){
    if(is_kernel_vaddr(vaddr))syscall_exit(-1);
}

void syscall_halt(void){
	shutdown_power_off();
}

void syscall_exit (int status){
    struct thread *cur =thread_current();
	cur->exit = status;
    printf("%s: exit(%d)\n", cur->name, status);
	thread_exit();
}

pid_t syscall_exec (const char *file){
	return process_execute(file);
}

int syscall_wait (pid_t pid){
	return process_wait(pid);
}

int syscall_read (int fd, void *buffer, unsigned size){
    if(fd==0){
        int count=0;
        for(count=0;count<size;count++){
            char temp=input_getc();
            if(temp =='\0') break;
        }
        return count;
    }

    else return -1;

}

int syscall_write (int fd, const void *buffer, unsigned size){
    if(fd!=1) return -1;
    putbuf(buffer, size);
    return size;
}

int syscall_fibonacci(int n){
    int n1=0, n2=1;
    int n3=n1+n2;
   
    switch(n){
        case 1:
            n3=n1;
            break;
        case 2:
            n3=n2;
            break;
        default:
            for(int i=3;i<n;i++){
                n1=n2;
                n2=n3;
                n3=n1+n3;
            }
         
            break;
    }
    return n3;
}

int get_max(int a, int b){
    return (a>b) ? a:b;
}

int syscall_max_of_four_int(int a, int b, int c, int d){
    return get_max(get_max(a,b), get_max(c,d));
}

