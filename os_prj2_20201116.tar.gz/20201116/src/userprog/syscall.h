#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "process.h"

typedef int pid_t;
#define PID_ERROR ((pid_t)-1)

void user_vaddr(const void * vaddr);
void syscall_init (void);
void syscall_halt(void);
int syscall_wait(pid_t);
void syscall_exit(int status);
pid_t syscall_exec(const char*file);
int call(pid_t);
int syscall_read(int fd, void *buffer, unsigned length);
int syscall_write(int fd, const void *buffer, unsigned length);
int syscall_fibonacci(int n);
int get_max(int a, int b);
int syscall_max_of_four_int(int a, int b, int c, int d);

bool syscall_create(const char*file, unsigned initial_size);
bool syscall_remove(const char* file);
int syscall_open(const char* file);
int syscall_filesize(int fd);
void syscall_seek(int fd, unsigned position);
unsigned syscall_tell(int fd);
void syscall_close(int fd);


#endif /* userprog/syscall.h */
