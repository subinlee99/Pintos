#include <stdio.h>
#include <syscall.h>
#include <stdlib.h>

int main (int argc, char**argv){
    int result =fibonacci(atoi(*(argv+1)));
	printf("%d\n", fibonacci(atoi(*(argv+1))));

	return EXIT_SUCCESS;
}
