#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include <string.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "threads/synch.h"
#define MEM_SIZE 4

static void syscall_handler (struct intr_frame *);

static void
syscall_handler (struct intr_frame *f UNUSED)
{

    uint32_t sys_num=*((uint32_t*)(f->esp));
    uint32_t arg1 =*(uint32_t*)(f->esp+MEM_SIZE);
    uint32_t arg2 =*(uint32_t*)(f->esp+2*MEM_SIZE);
    uint32_t arg3 =*(uint32_t*)(f->esp+3*MEM_SIZE);
    uint32_t arg4 =*(uint32_t*)(f->esp+4*MEM_SIZE);
    user_vaddr(f->esp+4);
    switch(sys_num){
        case SYS_HALT:
            syscall_halt();
            break;
        case SYS_EXIT:
            syscall_exit(arg1);
            break;
        case SYS_EXEC :
            f->eax = syscall_exec((char*)arg1);
            break;
        case SYS_WAIT:
            f->eax = syscall_wait(arg1);
            break;
        case SYS_READ:
            user_vaddr(f->esp+2*MEM_SIZE);
            user_vaddr(f->esp+3*MEM_SIZE);
            f->eax = syscall_read ((int)arg1,(void*)arg2,(unsigned)arg3);
            break;
        case SYS_WRITE:
            user_vaddr(f->esp+2*MEM_SIZE);
            user_vaddr(f->esp+3*MEM_SIZE);
            f->eax = syscall_write((int)arg1,(const void*)arg2,(unsigned)arg3);
            break;
        case SYS_FIB:
            f->eax=syscall_fibonacci((int)arg1);
            break;
        case SYS_MAXFOUR:
            user_vaddr(f->esp+2*MEM_SIZE);
            user_vaddr(f->esp+3*MEM_SIZE);
            user_vaddr(f->esp+4*MEM_SIZE);
            f->eax=syscall_max_of_four_int((int)arg1, (int)arg2,(int)arg3, (int)arg4);
            break;
        case SYS_CREATE:
            user_vaddr(f->esp+2*MEM_SIZE);
            f->eax = syscall_create((const char*)arg1, (unsigned)arg2);
            break;
        case SYS_REMOVE:
            f->eax = syscall_remove((const char*)arg1);
            break;
        case SYS_OPEN:
            f->eax = syscall_open((const char*)arg1);
            break;
        case SYS_CLOSE:
            syscall_close((int)arg1);
            break;
        case SYS_FILESIZE:
            f->eax = syscall_filesize((int)arg1);
            break;
        case SYS_SEEK:
            user_vaddr(f->esp+2*MEM_SIZE);
            syscall_seek((int)arg1, (unsigned)arg2);
            break;
        case SYS_TELL:
            f->eax = syscall_tell((int)arg1);
            break;
   }

    return;
}

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void user_vaddr(const void *vaddr){
    if(is_kernel_vaddr(vaddr))syscall_exit(-1);
}

void syscall_halt(void){
	shutdown_power_off();
}

void syscall_exit (int status){
    struct thread *cur =thread_current();
    cur->exit = status;
    printf("%s: exit(%d)\n", cur->name, status);
    
	for(int i=3; i<FILE_SIZE; i++) if(thread_current()->fd[i]) syscall_close(i);
	
	struct list_elem *e = list_begin(&(thread_current())->child);

	while(e!=list_end(&(thread_current()->child))){
        struct thread* t=list_entry(e, struct thread, child_e);
		process_wait(t->tid);
		e=list_next(e);
	}

	file_close(thread_current()->cur_file);
	thread_exit();
}

pid_t syscall_exec (const char *file){
    return process_execute(file);
}

int syscall_wait (pid_t pid){
	return process_wait(pid);
}

int syscall_read (int fd, void *buffer, unsigned size){
    int value;
	lock_acquire(&filesys_lock);
    
    if(fd==0){
        int count=0;
        while(count<(int)size){
            char temp=input_getc();
            if(temp =='\0') break;
            count ++;
            value=count;
        }
        
    }

	else if(fd>=3){
		if(!thread_current()->fd[fd]) syscall_exit(-1);
        value = file_read(thread_current()->fd[fd], buffer, size);
	}
    
	else value= -1;
	
    lock_release(&filesys_lock);
    return value;
}

int syscall_write (int fd, const void *buffer, unsigned size){
	lock_acquire(&filesys_lock);
    
	if(fd==1){
		putbuf(buffer,size);
	}
    
	else if(fd>=3){
		if(!thread_current()->fd[fd]) syscall_exit(-1);
		
		size = file_write(thread_current()->fd[fd], buffer, size);
	}
	else size=-1;

    lock_release(&filesys_lock);
    return size;
}

int syscall_fibonacci(int n){
    int n1=0, n2=1;
    int n3=n1+n2;
   
    switch(n){
        case 1:
            n3=n1;
            break;
        case 2:
            n3=n2;
            break;
        default:
            for(int i=3;i<n;i++){
                n1=n2;
                n2=n3;
                n3=n1+n3;
            }
         
            break;
    }
    return n3;
}

int get_max(int a, int b){
    return (a>b) ? a:b;
}

int syscall_max_of_four_int(int a, int b, int c, int d){
    return get_max(get_max(a,b), get_max(c,d));
}


bool syscall_create (const char* file, unsigned initial_size){
	if(!file) syscall_exit(-1);
	return filesys_create(file, initial_size);
}

bool syscall_remove(const char* file){
	if(file==NULL)
		syscall_exit(-1);
	return filesys_remove(file);
}

int syscall_open(const char*file){
	if(!file) syscall_exit(-1);
	lock_acquire(&filesys_lock);
    int result =-1;
	struct file*fp = filesys_open(file);
	
	if(fp){
        int i=3;
        while(i<FILE_SIZE){
            if(!thread_current()->fd[i]){
                thread_current()->fd[i]=fp;
                result =i;
                break;
            }
            i++;
        }
	}
	lock_release(&filesys_lock);
	return result;
}

int syscall_filesize(int fd){
    if(!thread_current()->fd[fd]) syscall_exit(-1);
	return file_length(thread_current()->fd[fd]);
}

void syscall_seek(int fd, unsigned position){
	if(thread_current()->fd[fd]==NULL)
		syscall_exit(-1);
	file_seek(thread_current()->fd[fd], position);
}

unsigned syscall_tell(int fd){
    if(!thread_current()->fd[fd]) syscall_exit(-1);
	return file_tell(thread_current()->fd[fd]);
}

void syscall_close(int fd){
	if(!thread_current()->fd[fd])
        syscall_exit(-1);
	file_close(thread_current()->fd[fd]);
	thread_current()->fd[fd]=NULL;
}
